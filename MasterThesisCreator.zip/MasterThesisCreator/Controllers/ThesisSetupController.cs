﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MasterThesisCreator.Controllers
{
    public class ThesisSetupController : Controller
    {
        // GET: ThesisSetup
        public ActionResult Index()
        {
            return View();
        }
    }
}